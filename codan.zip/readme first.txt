files-

651pcmon - for mondotronics eprom programmer
651pcmic - for ma1000 eprom programmer
651pcfil - for any other eprom programmer (eg DSE kit etc)

choose the one applicable to your situation


update - update old 651pcxxx files to this version



