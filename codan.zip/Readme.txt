			Update Notice for 651PC v3.22
			=============================

	Changes to 651PC from version 3.21 :-

Bug Fixes:
        - On some new fast PCs the communications with the MA1000
          EPROM programmer did not not work correctly, this has been
          fixed.
        - The transceiver software version is now printed out on the
          channel listing to two decimal places.

			Update Notice for 651PC v3.20
			=============================

	Changes to 651PC from version 3.10 :-

Features Added:
	- Some users were reporting problems reading particular EPROMs which
	  has now been fixed with improved Mondotronic software incorporated
	  into the 651PC Codan software.

	- The Mondotronic EPROM programmer card address is now configurable
	  by the user from the transceiver select menu to allow for other cards
	  in PCs using the same card address.

	- The baud rate and com-port in use is now configurable by the user for
	  MA1000 serial programmers.

	- MA1000 serial communication has been improved.

	- 21v 27256 EPROMS with no device signatures are now supported.

	- Option A is now supported and recognised in the channel printout.

	- Channel help screens have been updated to reflect the 23MHz upper
	  transmit limit with option H marine transceivers.

	- EPROM 90- number now read from EPROM and, in display information after
	  "READ EPROM" the 90- number now includes the suffix.

	- There is now no difference in operation of upper or lower case
	  letters within channel entry.

	- Serial number and order number are now programmed in the EPROM.

Please Note:
EPROMs should not be placed in the Mondotronic programmer until the 651PC
software is running. The EPROM socket is set-up when the program is first
started and under advice from Mondotronic, it is best if the EPROM socket
is vacant during this initialisation.

